﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace PFinalVS.Metodos
{
    class Vaciar
    {
        public static void empty (TextBox un, TextBox dos, TextBox tre, TextBox cua, TextBox cin, TextBox sei, TextBox siet, TextBox ocho, TextBox nuev, TextBox diez,
            TextBox once, TextBox doce, TextBox trece, TextBox cato, TextBox quin, TextBox dieci, TextBox diesi, TextBox dieoch, TextBox dienue, TextBox veinte,
            TextBox vuno, TextBox vdos, TextBox vtres, TextBox vcuatro, TextBox vcinq, TextBox vseis, TextBox vsiet,TextBox vocho, TextBox vnuev, TextBox treinta,
            TextBox tuno, TextBox tdos, TextBox ttres, TextBox tcuatro, TextBox tcinq, TextBox tseis, TextBox tsiet, TextBox tocho, TextBox tnueve, TextBox cuarenta)
        {
            un.Text = null;
            dos.Text = null;
            tre.Text = null;
            cua.Text = null;
            cin.Text = null;
            sei.Text = null;
            siet.Text = null;
            ocho.Text = null;
            nuev.Text = null;
            diez.Text = null;
            once.Text = null;
            doce.Text = null;
            trece.Text = null;
            cato.Text = null;
            quin.Text = null;
            dieci.Text = null;
            diesi.Text = null;
            dieoch.Text = null;
            dienue.Text = null;
            veinte.Text = null;
            vuno.Text = null;
            vdos.Text = null;
            vtres.Text = null;
            vcuatro.Text = null;
            vcinq.Text = null;
            vseis.Text = null;
            vsiet.Text = null;
            vocho.Text = null;
            vnuev.Text = null;
            treinta.Text = null;
            tuno.Text = null;
            tdos.Text = null;
            ttres.Text = null;
            tcuatro.Text = null;
            tcinq.Text = null;
            tseis.Text = null;
            tsiet.Text = null;
            tocho.Text = null;
            tnueve.Text = null;
            cuarenta.Text = null;


        }
        

        }
    }


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PFinalVS.Metodos
{
    class AmasM
    {
        public static int cerouno (string acumulador, string multiplicador) // SUMA A ACUMULADOR CON MULTIPLICADOR CUANDO SE TENGA 0 Y 1
        {
            return int.Parse(acumulador) + int.Parse(multiplicador);
        }
    }
}

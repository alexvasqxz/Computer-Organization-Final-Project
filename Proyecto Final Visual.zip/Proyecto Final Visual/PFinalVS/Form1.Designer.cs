﻿namespace PFinalVS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtboxmultiplicadord = new System.Windows.Forms.TextBox();
            this.txtboxmultiplicandod = new System.Windows.Forms.TextBox();
            this.txtboxmultiplicadorbi = new System.Windows.Forms.TextBox();
            this.txtboxmultiplicandobi = new System.Windows.Forms.TextBox();
            this.txtboxA = new System.Windows.Forms.TextBox();
            this.txtboxQ1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtBoxAP1 = new System.Windows.Forms.TextBox();
            this.txtBoxQP1 = new System.Windows.Forms.TextBox();
            this.txtBoxQ1P1 = new System.Windows.Forms.TextBox();
            this.txtBoxMP1 = new System.Windows.Forms.TextBox();
            this.txtBoxAP11 = new System.Windows.Forms.TextBox();
            this.txtBoxQP11 = new System.Windows.Forms.TextBox();
            this.txtBoxQ1P11 = new System.Windows.Forms.TextBox();
            this.txtBoxAP2 = new System.Windows.Forms.TextBox();
            this.txtBoxAP22 = new System.Windows.Forms.TextBox();
            this.txtBoxAP3 = new System.Windows.Forms.TextBox();
            this.txtBoxAP33 = new System.Windows.Forms.TextBox();
            this.txtBoxAP4 = new System.Windows.Forms.TextBox();
            this.txtBoxAP44 = new System.Windows.Forms.TextBox();
            this.txtBoxQP2 = new System.Windows.Forms.TextBox();
            this.txtBoxQP22 = new System.Windows.Forms.TextBox();
            this.txtBoxQP3 = new System.Windows.Forms.TextBox();
            this.txtBoxQP33 = new System.Windows.Forms.TextBox();
            this.txtBoxQP4 = new System.Windows.Forms.TextBox();
            this.txtBoxQP44 = new System.Windows.Forms.TextBox();
            this.txtBoxQ1P2 = new System.Windows.Forms.TextBox();
            this.txtBoxQ1P22 = new System.Windows.Forms.TextBox();
            this.txtBoxQ1P3 = new System.Windows.Forms.TextBox();
            this.txtBoxQ1P33 = new System.Windows.Forms.TextBox();
            this.txtBoxQ1P4 = new System.Windows.Forms.TextBox();
            this.txtBoxQ1P44 = new System.Windows.Forms.TextBox();
            this.txtBoxMP2 = new System.Windows.Forms.TextBox();
            this.txtBoxMP3 = new System.Windows.Forms.TextBox();
            this.txtBoxMP4 = new System.Windows.Forms.TextBox();
            this.txtBoxProc0 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtBoxProc1 = new System.Windows.Forms.TextBox();
            this.txtBoxProc2 = new System.Windows.Forms.TextBox();
            this.txtBoxProc3 = new System.Windows.Forms.TextBox();
            this.txtBoxProc4 = new System.Windows.Forms.TextBox();
            this.txtBoxResultado = new System.Windows.Forms.TextBox();
            this.lblRes = new System.Windows.Forms.Label();
            this.bttnPaP = new System.Windows.Forms.Button();
            this.bttnCiclo1 = new System.Windows.Forms.Button();
            this.bttnCiclo2 = new System.Windows.Forms.Button();
            this.bttnCiclo3 = new System.Windows.Forms.Button();
            this.bttnCiclo4 = new System.Windows.Forms.Button();
            this.bttnReset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.button1.Location = new System.Drawing.Point(1150, 795);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(262, 98);
            this.button1.TabIndex = 0;
            this.button1.Text = " MULTIPLICAR (MOSTRAR RESULTADO)";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(454, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "M";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(454, 165);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Q";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtboxmultiplicadord
            // 
            this.txtboxmultiplicadord.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtboxmultiplicadord.Location = new System.Drawing.Point(574, 76);
            this.txtboxmultiplicadord.Name = "txtboxmultiplicadord";
            this.txtboxmultiplicadord.Size = new System.Drawing.Size(160, 31);
            this.txtboxmultiplicadord.TabIndex = 3;
            this.txtboxmultiplicadord.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtboxmultiplicadord.TextChanged += new System.EventHandler(this.txtboxmultiplicadord_TextChanged);
            // 
            // txtboxmultiplicandod
            // 
            this.txtboxmultiplicandod.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtboxmultiplicandod.Location = new System.Drawing.Point(574, 165);
            this.txtboxmultiplicandod.Name = "txtboxmultiplicandod";
            this.txtboxmultiplicandod.Size = new System.Drawing.Size(160, 31);
            this.txtboxmultiplicandod.TabIndex = 4;
            this.txtboxmultiplicandod.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtboxmultiplicandod.TextChanged += new System.EventHandler(this.txtboxmultiplicandod_TextChanged);
            // 
            // txtboxmultiplicadorbi
            // 
            this.txtboxmultiplicadorbi.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtboxmultiplicadorbi.Location = new System.Drawing.Point(519, 300);
            this.txtboxmultiplicadorbi.Name = "txtboxmultiplicadorbi";
            this.txtboxmultiplicadorbi.Size = new System.Drawing.Size(198, 31);
            this.txtboxmultiplicadorbi.TabIndex = 5;
            this.txtboxmultiplicadorbi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtboxmultiplicadorbi.TextChanged += new System.EventHandler(this.txtboxmultiplicadorbi_TextChanged);
            // 
            // txtboxmultiplicandobi
            // 
            this.txtboxmultiplicandobi.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtboxmultiplicandobi.Location = new System.Drawing.Point(215, 300);
            this.txtboxmultiplicandobi.Name = "txtboxmultiplicandobi";
            this.txtboxmultiplicandobi.Size = new System.Drawing.Size(198, 31);
            this.txtboxmultiplicandobi.TabIndex = 6;
            this.txtboxmultiplicandobi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtboxmultiplicandobi.TextChanged += new System.EventHandler(this.txtboxmultiplicandobi_TextChanged);
            // 
            // txtboxA
            // 
            this.txtboxA.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtboxA.Location = new System.Drawing.Point(59, 300);
            this.txtboxA.Name = "txtboxA";
            this.txtboxA.Size = new System.Drawing.Size(134, 31);
            this.txtboxA.TabIndex = 7;
            this.txtboxA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtboxA.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtboxQ1
            // 
            this.txtboxQ1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtboxQ1.Location = new System.Drawing.Point(434, 300);
            this.txtboxQ1.Name = "txtboxQ1";
            this.txtboxQ1.Size = new System.Drawing.Size(48, 31);
            this.txtboxQ1.TabIndex = 8;
            this.txtboxQ1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtboxQ1.TextChanged += new System.EventHandler(this.txtboxQ1_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(117, 256);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 25);
            this.label3.TabIndex = 9;
            this.label3.Text = "A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(302, 256);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 25);
            this.label4.TabIndex = 10;
            this.label4.Text = "Q";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(442, 256);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 25);
            this.label5.TabIndex = 11;
            this.label5.Text = "Q1";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(602, 256);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 25);
            this.label6.TabIndex = 12;
            this.label6.Text = "M";
            // 
            // txtBoxAP1
            // 
            this.txtBoxAP1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxAP1.Location = new System.Drawing.Point(59, 363);
            this.txtBoxAP1.Name = "txtBoxAP1";
            this.txtBoxAP1.Size = new System.Drawing.Size(134, 31);
            this.txtBoxAP1.TabIndex = 13;
            this.txtBoxAP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxQP1
            // 
            this.txtBoxQP1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQP1.Location = new System.Drawing.Point(215, 363);
            this.txtBoxQP1.Name = "txtBoxQP1";
            this.txtBoxQP1.Size = new System.Drawing.Size(198, 31);
            this.txtBoxQP1.TabIndex = 14;
            this.txtBoxQP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBoxQP1.TextChanged += new System.EventHandler(this.txtBoxQP1_TextChanged);
            // 
            // txtBoxQ1P1
            // 
            this.txtBoxQ1P1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQ1P1.Location = new System.Drawing.Point(434, 363);
            this.txtBoxQ1P1.Name = "txtBoxQ1P1";
            this.txtBoxQ1P1.Size = new System.Drawing.Size(48, 31);
            this.txtBoxQ1P1.TabIndex = 15;
            this.txtBoxQ1P1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxMP1
            // 
            this.txtBoxMP1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxMP1.Location = new System.Drawing.Point(519, 381);
            this.txtBoxMP1.Name = "txtBoxMP1";
            this.txtBoxMP1.Size = new System.Drawing.Size(198, 31);
            this.txtBoxMP1.TabIndex = 16;
            this.txtBoxMP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxAP11
            // 
            this.txtBoxAP11.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxAP11.Location = new System.Drawing.Point(59, 400);
            this.txtBoxAP11.Name = "txtBoxAP11";
            this.txtBoxAP11.Size = new System.Drawing.Size(134, 31);
            this.txtBoxAP11.TabIndex = 17;
            this.txtBoxAP11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxQP11
            // 
            this.txtBoxQP11.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQP11.Location = new System.Drawing.Point(215, 399);
            this.txtBoxQP11.Name = "txtBoxQP11";
            this.txtBoxQP11.Size = new System.Drawing.Size(198, 31);
            this.txtBoxQP11.TabIndex = 18;
            this.txtBoxQP11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxQ1P11
            // 
            this.txtBoxQ1P11.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQ1P11.Location = new System.Drawing.Point(434, 399);
            this.txtBoxQ1P11.Name = "txtBoxQ1P11";
            this.txtBoxQ1P11.Size = new System.Drawing.Size(48, 31);
            this.txtBoxQ1P11.TabIndex = 19;
            this.txtBoxQ1P11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxAP2
            // 
            this.txtBoxAP2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxAP2.Location = new System.Drawing.Point(59, 473);
            this.txtBoxAP2.Name = "txtBoxAP2";
            this.txtBoxAP2.Size = new System.Drawing.Size(134, 31);
            this.txtBoxAP2.TabIndex = 20;
            this.txtBoxAP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxAP22
            // 
            this.txtBoxAP22.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxAP22.Location = new System.Drawing.Point(59, 510);
            this.txtBoxAP22.Name = "txtBoxAP22";
            this.txtBoxAP22.Size = new System.Drawing.Size(134, 31);
            this.txtBoxAP22.TabIndex = 21;
            this.txtBoxAP22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxAP3
            // 
            this.txtBoxAP3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxAP3.Location = new System.Drawing.Point(59, 579);
            this.txtBoxAP3.Name = "txtBoxAP3";
            this.txtBoxAP3.Size = new System.Drawing.Size(134, 31);
            this.txtBoxAP3.TabIndex = 22;
            this.txtBoxAP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxAP33
            // 
            this.txtBoxAP33.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxAP33.Location = new System.Drawing.Point(59, 616);
            this.txtBoxAP33.Name = "txtBoxAP33";
            this.txtBoxAP33.Size = new System.Drawing.Size(134, 31);
            this.txtBoxAP33.TabIndex = 23;
            this.txtBoxAP33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxAP4
            // 
            this.txtBoxAP4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxAP4.Location = new System.Drawing.Point(59, 679);
            this.txtBoxAP4.Name = "txtBoxAP4";
            this.txtBoxAP4.Size = new System.Drawing.Size(134, 31);
            this.txtBoxAP4.TabIndex = 24;
            this.txtBoxAP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxAP44
            // 
            this.txtBoxAP44.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxAP44.Location = new System.Drawing.Point(59, 716);
            this.txtBoxAP44.Name = "txtBoxAP44";
            this.txtBoxAP44.Size = new System.Drawing.Size(134, 31);
            this.txtBoxAP44.TabIndex = 25;
            this.txtBoxAP44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxQP2
            // 
            this.txtBoxQP2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQP2.Location = new System.Drawing.Point(215, 473);
            this.txtBoxQP2.Name = "txtBoxQP2";
            this.txtBoxQP2.Size = new System.Drawing.Size(198, 31);
            this.txtBoxQP2.TabIndex = 26;
            this.txtBoxQP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxQP22
            // 
            this.txtBoxQP22.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQP22.Location = new System.Drawing.Point(215, 510);
            this.txtBoxQP22.Name = "txtBoxQP22";
            this.txtBoxQP22.Size = new System.Drawing.Size(198, 31);
            this.txtBoxQP22.TabIndex = 27;
            this.txtBoxQP22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxQP3
            // 
            this.txtBoxQP3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQP3.Location = new System.Drawing.Point(215, 579);
            this.txtBoxQP3.Name = "txtBoxQP3";
            this.txtBoxQP3.Size = new System.Drawing.Size(198, 31);
            this.txtBoxQP3.TabIndex = 28;
            this.txtBoxQP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxQP33
            // 
            this.txtBoxQP33.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQP33.Location = new System.Drawing.Point(215, 616);
            this.txtBoxQP33.Name = "txtBoxQP33";
            this.txtBoxQP33.Size = new System.Drawing.Size(198, 31);
            this.txtBoxQP33.TabIndex = 29;
            this.txtBoxQP33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxQP4
            // 
            this.txtBoxQP4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQP4.Location = new System.Drawing.Point(215, 679);
            this.txtBoxQP4.Name = "txtBoxQP4";
            this.txtBoxQP4.Size = new System.Drawing.Size(198, 31);
            this.txtBoxQP4.TabIndex = 30;
            this.txtBoxQP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxQP44
            // 
            this.txtBoxQP44.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQP44.Location = new System.Drawing.Point(215, 716);
            this.txtBoxQP44.Name = "txtBoxQP44";
            this.txtBoxQP44.Size = new System.Drawing.Size(198, 31);
            this.txtBoxQP44.TabIndex = 31;
            this.txtBoxQP44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxQ1P2
            // 
            this.txtBoxQ1P2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQ1P2.Location = new System.Drawing.Point(434, 473);
            this.txtBoxQ1P2.Name = "txtBoxQ1P2";
            this.txtBoxQ1P2.Size = new System.Drawing.Size(48, 31);
            this.txtBoxQ1P2.TabIndex = 32;
            this.txtBoxQ1P2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxQ1P22
            // 
            this.txtBoxQ1P22.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQ1P22.Location = new System.Drawing.Point(434, 510);
            this.txtBoxQ1P22.Name = "txtBoxQ1P22";
            this.txtBoxQ1P22.Size = new System.Drawing.Size(48, 31);
            this.txtBoxQ1P22.TabIndex = 33;
            this.txtBoxQ1P22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxQ1P3
            // 
            this.txtBoxQ1P3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQ1P3.Location = new System.Drawing.Point(434, 579);
            this.txtBoxQ1P3.Name = "txtBoxQ1P3";
            this.txtBoxQ1P3.Size = new System.Drawing.Size(48, 31);
            this.txtBoxQ1P3.TabIndex = 34;
            this.txtBoxQ1P3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxQ1P33
            // 
            this.txtBoxQ1P33.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQ1P33.Location = new System.Drawing.Point(434, 616);
            this.txtBoxQ1P33.Name = "txtBoxQ1P33";
            this.txtBoxQ1P33.Size = new System.Drawing.Size(48, 31);
            this.txtBoxQ1P33.TabIndex = 35;
            this.txtBoxQ1P33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxQ1P4
            // 
            this.txtBoxQ1P4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQ1P4.Location = new System.Drawing.Point(434, 679);
            this.txtBoxQ1P4.Name = "txtBoxQ1P4";
            this.txtBoxQ1P4.Size = new System.Drawing.Size(48, 31);
            this.txtBoxQ1P4.TabIndex = 36;
            this.txtBoxQ1P4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxQ1P44
            // 
            this.txtBoxQ1P44.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxQ1P44.Location = new System.Drawing.Point(434, 716);
            this.txtBoxQ1P44.Name = "txtBoxQ1P44";
            this.txtBoxQ1P44.Size = new System.Drawing.Size(48, 31);
            this.txtBoxQ1P44.TabIndex = 37;
            this.txtBoxQ1P44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxMP2
            // 
            this.txtBoxMP2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxMP2.Location = new System.Drawing.Point(519, 493);
            this.txtBoxMP2.Name = "txtBoxMP2";
            this.txtBoxMP2.Size = new System.Drawing.Size(198, 31);
            this.txtBoxMP2.TabIndex = 38;
            this.txtBoxMP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxMP3
            // 
            this.txtBoxMP3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxMP3.Location = new System.Drawing.Point(519, 599);
            this.txtBoxMP3.Name = "txtBoxMP3";
            this.txtBoxMP3.Size = new System.Drawing.Size(198, 31);
            this.txtBoxMP3.TabIndex = 39;
            this.txtBoxMP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxMP4
            // 
            this.txtBoxMP4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxMP4.Location = new System.Drawing.Point(519, 701);
            this.txtBoxMP4.Name = "txtBoxMP4";
            this.txtBoxMP4.Size = new System.Drawing.Size(198, 31);
            this.txtBoxMP4.TabIndex = 40;
            this.txtBoxMP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxProc0
            // 
            this.txtBoxProc0.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxProc0.Location = new System.Drawing.Point(781, 300);
            this.txtBoxProc0.Name = "txtBoxProc0";
            this.txtBoxProc0.Size = new System.Drawing.Size(268, 31);
            this.txtBoxProc0.TabIndex = 41;
            this.txtBoxProc0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(852, 256);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 25);
            this.label7.TabIndex = 42;
            this.label7.Text = "Proceso";
            // 
            // txtBoxProc1
            // 
            this.txtBoxProc1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxProc1.Location = new System.Drawing.Point(781, 381);
            this.txtBoxProc1.Name = "txtBoxProc1";
            this.txtBoxProc1.Size = new System.Drawing.Size(268, 31);
            this.txtBoxProc1.TabIndex = 43;
            this.txtBoxProc1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxProc2
            // 
            this.txtBoxProc2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxProc2.Location = new System.Drawing.Point(781, 493);
            this.txtBoxProc2.Name = "txtBoxProc2";
            this.txtBoxProc2.Size = new System.Drawing.Size(268, 31);
            this.txtBoxProc2.TabIndex = 44;
            this.txtBoxProc2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxProc3
            // 
            this.txtBoxProc3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxProc3.Location = new System.Drawing.Point(781, 599);
            this.txtBoxProc3.Name = "txtBoxProc3";
            this.txtBoxProc3.Size = new System.Drawing.Size(268, 31);
            this.txtBoxProc3.TabIndex = 45;
            this.txtBoxProc3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxProc4
            // 
            this.txtBoxProc4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxProc4.Location = new System.Drawing.Point(781, 701);
            this.txtBoxProc4.Name = "txtBoxProc4";
            this.txtBoxProc4.Size = new System.Drawing.Size(268, 31);
            this.txtBoxProc4.TabIndex = 46;
            this.txtBoxProc4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBoxResultado
            // 
            this.txtBoxResultado.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBoxResultado.Location = new System.Drawing.Point(416, 795);
            this.txtBoxResultado.Name = "txtBoxResultado";
            this.txtBoxResultado.Size = new System.Drawing.Size(267, 31);
            this.txtBoxResultado.TabIndex = 47;
            this.txtBoxResultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblRes
            // 
            this.lblRes.AutoSize = true;
            this.lblRes.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblRes.Location = new System.Drawing.Point(270, 795);
            this.lblRes.Name = "lblRes";
            this.lblRes.Size = new System.Drawing.Size(109, 25);
            this.lblRes.TabIndex = 48;
            this.lblRes.Text = "Resultado";
            // 
            // bttnPaP
            // 
            this.bttnPaP.BackColor = System.Drawing.Color.LightBlue;
            this.bttnPaP.Location = new System.Drawing.Point(1150, 219);
            this.bttnPaP.Name = "bttnPaP";
            this.bttnPaP.Size = new System.Drawing.Size(262, 98);
            this.bttnPaP.TabIndex = 49;
            this.bttnPaP.Text = "PASO A PASO";
            this.bttnPaP.UseVisualStyleBackColor = false;
            this.bttnPaP.Click += new System.EventHandler(this.BttnPaP_Click);
            // 
            // bttnCiclo1
            // 
            this.bttnCiclo1.BackColor = System.Drawing.Color.LightBlue;
            this.bttnCiclo1.Location = new System.Drawing.Point(1150, 359);
            this.bttnCiclo1.Name = "bttnCiclo1";
            this.bttnCiclo1.Size = new System.Drawing.Size(262, 75);
            this.bttnCiclo1.TabIndex = 50;
            this.bttnCiclo1.Text = "CICLO 1";
            this.bttnCiclo1.UseVisualStyleBackColor = false;
            this.bttnCiclo1.Click += new System.EventHandler(this.BttnCiclo1_Click);
            // 
            // bttnCiclo2
            // 
            this.bttnCiclo2.BackColor = System.Drawing.Color.LightBlue;
            this.bttnCiclo2.Location = new System.Drawing.Point(1150, 473);
            this.bttnCiclo2.Name = "bttnCiclo2";
            this.bttnCiclo2.Size = new System.Drawing.Size(262, 71);
            this.bttnCiclo2.TabIndex = 51;
            this.bttnCiclo2.Text = "CICLO 2";
            this.bttnCiclo2.UseVisualStyleBackColor = false;
            this.bttnCiclo2.Click += new System.EventHandler(this.BttnCiclo2_Click);
            // 
            // bttnCiclo3
            // 
            this.bttnCiclo3.BackColor = System.Drawing.Color.LightBlue;
            this.bttnCiclo3.Location = new System.Drawing.Point(1150, 579);
            this.bttnCiclo3.Name = "bttnCiclo3";
            this.bttnCiclo3.Size = new System.Drawing.Size(262, 71);
            this.bttnCiclo3.TabIndex = 52;
            this.bttnCiclo3.Text = "CICLO 3";
            this.bttnCiclo3.UseVisualStyleBackColor = false;
            this.bttnCiclo3.Click += new System.EventHandler(this.Button5_Click);
            // 
            // bttnCiclo4
            // 
            this.bttnCiclo4.BackColor = System.Drawing.Color.LightBlue;
            this.bttnCiclo4.Location = new System.Drawing.Point(1150, 681);
            this.bttnCiclo4.Name = "bttnCiclo4";
            this.bttnCiclo4.Size = new System.Drawing.Size(262, 71);
            this.bttnCiclo4.TabIndex = 53;
            this.bttnCiclo4.Text = "CICLO 4";
            this.bttnCiclo4.UseVisualStyleBackColor = false;
            this.bttnCiclo4.Click += new System.EventHandler(this.BttnCiclo4_Click);
            // 
            // bttnReset
            // 
            this.bttnReset.BackColor = System.Drawing.Color.WhiteSmoke;
            this.bttnReset.Location = new System.Drawing.Point(553, 935);
            this.bttnReset.Name = "bttnReset";
            this.bttnReset.Size = new System.Drawing.Size(235, 64);
            this.bttnReset.TabIndex = 54;
            this.bttnReset.Text = "REINICIAR";
            this.bttnReset.UseVisualStyleBackColor = false;
            this.bttnReset.Click += new System.EventHandler(this.BttnReset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1553, 1058);
            this.Controls.Add(this.bttnReset);
            this.Controls.Add(this.bttnCiclo4);
            this.Controls.Add(this.bttnCiclo3);
            this.Controls.Add(this.bttnCiclo2);
            this.Controls.Add(this.bttnCiclo1);
            this.Controls.Add(this.bttnPaP);
            this.Controls.Add(this.lblRes);
            this.Controls.Add(this.txtBoxResultado);
            this.Controls.Add(this.txtBoxProc4);
            this.Controls.Add(this.txtBoxProc3);
            this.Controls.Add(this.txtBoxProc2);
            this.Controls.Add(this.txtBoxProc1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtBoxProc0);
            this.Controls.Add(this.txtBoxMP4);
            this.Controls.Add(this.txtBoxMP3);
            this.Controls.Add(this.txtBoxMP2);
            this.Controls.Add(this.txtBoxQ1P44);
            this.Controls.Add(this.txtBoxQ1P4);
            this.Controls.Add(this.txtBoxQ1P33);
            this.Controls.Add(this.txtBoxQ1P3);
            this.Controls.Add(this.txtBoxQ1P22);
            this.Controls.Add(this.txtBoxQ1P2);
            this.Controls.Add(this.txtBoxQP44);
            this.Controls.Add(this.txtBoxQP4);
            this.Controls.Add(this.txtBoxQP33);
            this.Controls.Add(this.txtBoxQP3);
            this.Controls.Add(this.txtBoxQP22);
            this.Controls.Add(this.txtBoxQP2);
            this.Controls.Add(this.txtBoxAP44);
            this.Controls.Add(this.txtBoxAP4);
            this.Controls.Add(this.txtBoxAP33);
            this.Controls.Add(this.txtBoxAP3);
            this.Controls.Add(this.txtBoxAP22);
            this.Controls.Add(this.txtBoxAP2);
            this.Controls.Add(this.txtBoxQ1P11);
            this.Controls.Add(this.txtBoxQP11);
            this.Controls.Add(this.txtBoxAP11);
            this.Controls.Add(this.txtBoxMP1);
            this.Controls.Add(this.txtBoxQ1P1);
            this.Controls.Add(this.txtBoxQP1);
            this.Controls.Add(this.txtBoxAP1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtboxQ1);
            this.Controls.Add(this.txtboxA);
            this.Controls.Add(this.txtboxmultiplicandobi);
            this.Controls.Add(this.txtboxmultiplicadorbi);
            this.Controls.Add(this.txtboxmultiplicandod);
            this.Controls.Add(this.txtboxmultiplicadord);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtboxmultiplicadord;
        private System.Windows.Forms.TextBox txtboxmultiplicandod;
        private System.Windows.Forms.TextBox txtboxmultiplicadorbi;
        private System.Windows.Forms.TextBox txtboxmultiplicandobi;
        private System.Windows.Forms.TextBox txtboxA;
        private System.Windows.Forms.TextBox txtboxQ1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtBoxAP1;
        private System.Windows.Forms.TextBox txtBoxQP1;
        private System.Windows.Forms.TextBox txtBoxQ1P1;
        private System.Windows.Forms.TextBox txtBoxMP1;
        private System.Windows.Forms.TextBox txtBoxAP11;
        private System.Windows.Forms.TextBox txtBoxQP11;
        private System.Windows.Forms.TextBox txtBoxQ1P11;
        private System.Windows.Forms.TextBox txtBoxAP2;
        private System.Windows.Forms.TextBox txtBoxAP22;
        private System.Windows.Forms.TextBox txtBoxAP3;
        private System.Windows.Forms.TextBox txtBoxAP33;
        private System.Windows.Forms.TextBox txtBoxAP4;
        private System.Windows.Forms.TextBox txtBoxAP44;
        private System.Windows.Forms.TextBox txtBoxQP2;
        private System.Windows.Forms.TextBox txtBoxQP22;
        private System.Windows.Forms.TextBox txtBoxQP3;
        private System.Windows.Forms.TextBox txtBoxQP33;
        private System.Windows.Forms.TextBox txtBoxQP4;
        private System.Windows.Forms.TextBox txtBoxQP44;
        private System.Windows.Forms.TextBox txtBoxQ1P2;
        private System.Windows.Forms.TextBox txtBoxQ1P22;
        private System.Windows.Forms.TextBox txtBoxQ1P3;
        private System.Windows.Forms.TextBox txtBoxQ1P33;
        private System.Windows.Forms.TextBox txtBoxQ1P4;
        private System.Windows.Forms.TextBox txtBoxQ1P44;
        private System.Windows.Forms.TextBox txtBoxMP2;
        private System.Windows.Forms.TextBox txtBoxMP3;
        private System.Windows.Forms.TextBox txtBoxMP4;
        private System.Windows.Forms.TextBox txtBoxProc0;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtBoxProc1;
        private System.Windows.Forms.TextBox txtBoxProc2;
        private System.Windows.Forms.TextBox txtBoxProc3;
        private System.Windows.Forms.TextBox txtBoxProc4;
        private System.Windows.Forms.TextBox txtBoxResultado;
        private System.Windows.Forms.Label lblRes;
        private System.Windows.Forms.Button bttnPaP;
        private System.Windows.Forms.Button bttnCiclo1;
        private System.Windows.Forms.Button bttnCiclo2;
        private System.Windows.Forms.Button bttnCiclo3;
        private System.Windows.Forms.Button bttnCiclo4;
        private System.Windows.Forms.Button bttnReset;
    }
}

